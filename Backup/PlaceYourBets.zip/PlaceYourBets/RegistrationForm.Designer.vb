﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegistrationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RegistrationForm))
        Me.userLabel = New System.Windows.Forms.Label()
        Me.usernameTextBox = New System.Windows.Forms.TextBox()
        Me.registerButton = New System.Windows.Forms.Button()
        Me.closeButton = New System.Windows.Forms.Button()
        Me.LinkLabel = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'userLabel
        '
        Me.userLabel.Location = New System.Drawing.Point(364, 133)
        Me.userLabel.Name = "userLabel"
        Me.userLabel.Size = New System.Drawing.Size(64, 26)
        Me.userLabel.TabIndex = 5
        Me.userLabel.Text = "Username"
        Me.userLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'usernameTextBox
        '
        Me.usernameTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.usernameTextBox.Location = New System.Drawing.Point(247, 153)
        Me.usernameTextBox.Name = "usernameTextBox"
        Me.usernameTextBox.Size = New System.Drawing.Size(300, 20)
        Me.usernameTextBox.TabIndex = 0
        '
        'registerButton
        '
        Me.registerButton.BackColor = System.Drawing.Color.White
        Me.registerButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.registerButton.Location = New System.Drawing.Point(247, 210)
        Me.registerButton.Name = "registerButton"
        Me.registerButton.Size = New System.Drawing.Size(300, 50)
        Me.registerButton.TabIndex = 1
        Me.registerButton.Text = "Register"
        Me.registerButton.UseVisualStyleBackColor = False
        '
        'closeButton
        '
        Me.closeButton.BackColor = System.Drawing.Color.White
        Me.closeButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeButton.Location = New System.Drawing.Point(247, 266)
        Me.closeButton.Name = "closeButton"
        Me.closeButton.Size = New System.Drawing.Size(300, 50)
        Me.closeButton.TabIndex = 2
        Me.closeButton.Text = "Close"
        Me.closeButton.UseVisualStyleBackColor = False
        '
        'LinkLabel
        '
        Me.LinkLabel.BackColor = System.Drawing.Color.White
        Me.LinkLabel.Dock = System.Windows.Forms.DockStyle.Top
        Me.LinkLabel.Location = New System.Drawing.Point(0, 0)
        Me.LinkLabel.Name = "LinkLabel"
        Me.LinkLabel.Size = New System.Drawing.Size(798, 70)
        Me.LinkLabel.TabIndex = 9
        Me.LinkLabel.TabStop = True
        Me.LinkLabel.Text = "Enter the username you are registered with on PredictResults.co.uk. If you are no" & _
    "t a member please go to http://www.predictresults.co.uk/register-3/"
        Me.LinkLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RegistrationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(798, 402)
        Me.Controls.Add(Me.LinkLabel)
        Me.Controls.Add(Me.closeButton)
        Me.Controls.Add(Me.registerButton)
        Me.Controls.Add(Me.usernameTextBox)
        Me.Controls.Add(Me.userLabel)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "RegistrationForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "New User"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents userLabel As System.Windows.Forms.Label
    Friend WithEvents usernameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents registerButton As System.Windows.Forms.Button
    Friend WithEvents closeButton As System.Windows.Forms.Button
    Friend WithEvents LinkLabel As System.Windows.Forms.LinkLabel
End Class
