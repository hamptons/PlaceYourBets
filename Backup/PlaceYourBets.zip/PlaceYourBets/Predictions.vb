﻿Public Class Predictions




    Public Sub New()


    End Sub

    
End Class
